$(".panneau").click(function () {
  $(this).toggleClass("panneau-ouvert");
});
